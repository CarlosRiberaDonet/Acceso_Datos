/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import modelos.Empleados;


/**
 *
 * @author Carlos Ribera
 */
@Stateless
public class EmpleadoEJB {
    
    @PersistenceContext(unitName = "tema6PU")
    private EntityManager em;
    
    // Método para insertar un nuevo empleado en la BD
    public void insertarEmpleado(Empleados empleado){
        
        em.persist(empleado);
    }
    
    public boolean validarEmpleado(String nombreUsuario, String pass){
        
        try{
            em.createNamedQuery("Empleados.validarLogin", Empleados.class )
                    .setParameter("nombreUsuario", nombreUsuario)
                    .setParameter("contrasena", pass)
                    .getSingleResult();
            return true;
            
        } catch(NoResultException e){
            e.printStackTrace();
            return false;
        }
    }
}
