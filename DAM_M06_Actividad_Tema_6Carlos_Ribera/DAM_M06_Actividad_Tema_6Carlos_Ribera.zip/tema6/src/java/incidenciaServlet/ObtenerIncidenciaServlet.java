/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package incidenciaServlet;

import controllers.IncidenciaEJB;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelos.Incidencias;

/**
 *
 * @author Carlos Ribera
 */
@WebServlet(name = "ObtenerIncidenciaServlet", urlPatterns = {"/ObtenerIncidenciaServlet"})
public class ObtenerIncidenciaServlet extends HttpServlet {

    @EJB
    IncidenciaEJB ic;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ObtenerIncidenciaServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ObtenerIncidenciaServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        int incidenciaId = Integer.parseInt(request.getParameter("incidenciaId"));
        
        Incidencias incidencia = ic.getIncidenciaById(incidenciaId);
        
        if(incidencia != null){
            int id = incidencia.getId();
            Date fecha = incidencia.getFecha();
            String empleadoOrigen = incidencia.getIdEmpleadoOrigen().getNombreCompleto();
            String empleadoDestino = incidencia.getIdEmpleadoDestino().getNombreCompleto();
            String detalle = incidencia.getDetalle();
            char tipo = incidencia.getTipo();
            
            out.println("<html><body>");
            out.println("<h2>INCIDENCIA</h2>");
            out.println("<label>Id: " + id + "</label><br>");
            out.println("<label>Fecha: " + fecha + "</label><br>");
            out.println("<label>Empleado Origen: " + empleadoOrigen + "</label><br>");
            out.println("<label>Empleado Destino: " + empleadoDestino + "</label><br>");
            out.println("<label>Detalle: " + detalle + "</label><br>");
            out.println("<label>Tipo: " + tipo + "</label><br>");
            out.println("<a href='menu.jsp'>Volver al menú</a>");
            out.println("</body></html>");  
        } else{
            out.println("<html><body>");
            out.println("<h2>Incindencia con el número de id: " + incidenciaId + " no encontrada </h2>");
            out.println("<a href='menu.jsp'>Volver al menú</a>");
            out.println("</body></html>");
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
