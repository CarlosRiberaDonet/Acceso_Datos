/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package incidenciaServlet;

import controllers.EmpleadoEJB;
import controllers.IncidenciaEJB;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelos.Empleados;
import modelos.Incidencias;

/**
 *
 * @author Carlos Ribera
 */
@WebServlet(name = "IncidenciasEmpleadoDestinoServlet", urlPatterns = {"/IncidenciasEmpleadoDestinoServlet"})
public class IncidenciasEmpleadoDestinoServlet extends HttpServlet {

    @EJB
    IncidenciaEJB ic;
    @EJB
    EmpleadoEJB ec;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet IncidenciasEmpleadoDestinoServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet IncidenciasEmpleadoDestinoServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Recojo el parámetro enviado desde el formulario
        String nombreCompleto = request.getParameter("nombreCompleto").toLowerCase();
        System.out.println("Nombre completo recibido: " + nombreCompleto);

        // Llamo al método que busca el empleado mediante nombre completo
        Empleados empleado = ec.checkNombreCompleto(nombreCompleto);

        // Verifico si el empleado fue encontrado
        if (empleado != null) {
            System.out.println("Empleado encontrado: " + empleado.getNombreCompleto());

            // Obtengo el ID del empleado y recupero las incidencias asociadas como destino
            int idEmpleado = empleado.getId();
            List<Incidencias> incidenciasList = ic.getIncidenciasEmpleadoDestino(idEmpleado);

            // Compruebo si hay incidencias asociadas
            if (incidenciasList != null && !incidenciasList.isEmpty()) {
                // Recorro y muestro los datos de cada incidencia
                for (Incidencias i : incidenciasList) {
                    out.println("<hr>");
                    out.println("<p>Id: " + i.getId() + "</p>");
                    out.println("<p>Fecha: " + i.getFecha() + "</p>");
                    out.println("<p>Empleado Origen: " + i.getIdEmpleadoOrigen().getNombreCompleto() + "</p>");
                    out.println("<p>Empleado Destino: " + i.getIdEmpleadoDestino().getNombreCompleto() + "</p>");
                    out.println("<p>Detalle: " + i.getDetalle() + "</p>");
                    out.println("<p>Tipo: " + i.getTipo() + "</p>");
                }
            } else {
                // Si no hay incidencias, muestro mensaje
                out.println("<p>El empleado no tiene incidencias destinadas.</p>");
            }

        } else {
            // Si no se encuentra el empleado, informo
            out.println("<p>No se encontró ningún empleado con ese nombre completo.</p>");
        }
        out.println("<br><a href='menu.jsp'>Volver al menú</a>");
        out.println("</body></html>");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
